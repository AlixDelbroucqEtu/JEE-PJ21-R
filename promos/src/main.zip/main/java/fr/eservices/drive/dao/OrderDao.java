package fr.eservices.drive.dao;

public interface OrderDao {

}
