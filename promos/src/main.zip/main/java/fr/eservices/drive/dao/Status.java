package fr.eservices.drive.dao;

public enum Status {
	
	ORDERED,
	READY_TO_DELIVER,
	DELIVERED

}
