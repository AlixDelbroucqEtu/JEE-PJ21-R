package fr.eservices.drive.dao;

import fr.eservices.drive.model.Article;

public interface ArticleDao {
	
	Article find(String id);

}
