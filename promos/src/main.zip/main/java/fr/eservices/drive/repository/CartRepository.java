package fr.eservices.drive.repository;

import fr.eservices.drive.dao.CartDao;

public interface CartRepository 
extends CartDao
{

}
